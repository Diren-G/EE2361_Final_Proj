#ifndef HARPE507_LAB5_ASM_H
#define HARPE507_LAB5_ASM_H

void delay_1ms(void);
void delay_200us(void);

#endif //HARPE507_LAB5_ASM_H