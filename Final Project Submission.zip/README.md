# EE2361_Final_Proj
A photo-resistor based hole punch reader for the PIC24FJ64GA002.
